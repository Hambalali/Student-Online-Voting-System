import java.util.Scanner;

public class vote extends proje2 {
    public vote(){
        super();
    }
    public static void main(String[] args) {
        Scanner mei = new Scanner(System.in);
        proje2 obj = new proje2();
        participent par=new participent();
        obj.setname();
        obj.setregNo();
        obj.copy();
        obj.toStringx();
        par.display();
    }
}