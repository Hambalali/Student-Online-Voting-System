public interface view{
    public void setname();
    public void setregNo(); 
} 