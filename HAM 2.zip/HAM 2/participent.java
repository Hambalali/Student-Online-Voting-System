import java.util.Scanner;
public class participent{
    public participent(){

    }
    public void display(){
        String yes ="yes";
        int menu;
        do{
        System.out.println("\t\t\t\tPRESIDENT WITH REPRESENTERS");
        String [] president={"Fiston Kalala Mayele","Mundhir Mussa Haji","Fatma Machano Khamis","Lailat Ali Juma"};
        String [] repre={"Salim Sudi Saad","Maliki Abdulla Ally","Maryam Muhidin Hamad","Junaina Mussa Kibwan"};
        for(int i=0;i<repre.length;i++){
            System.out.println((i+1)+".President: "+president[i]+"\t\tRepresenter: "+repre[i]);
        }
        Scanner mabii=new Scanner(System.in);
        String [] detel={"\t\t\tPRESIDENT DETAIL\nname: Fiston Kalala Mayele\nlevel: President\ncompus: Chwaka\ncouse: BAF\naccyear: 2020/21","\t\t\tPRESIDENT DETAIL\nname: Mundhir Muss Haji\nlevel: President\ncompus: Kizimban\ncouse: WLF\naccyear: 2019/20","\t\t\tPRESIDENT DETAIL\nname: Fatma Machano Khamis\nlevel: President\ncompus: Mbweni\ncouse: Phamacy\naccyear: 2018/19","\t\t\tPRESIDENT DETAIL\nname: Lailat Ali Juma\nlevel: President\ncompus: Tunguu\ncouse: BITAM\naccyear: 2022/23"};
        String [] deteil={"\n\n\t\t\tREPRESENT DETAIL\nname: Salim Sudi Saad\nlevel: Representer\ncompus: Maruhubi\ncouse: BAGES\naccyear: 2022/23","\n\n\t\t\tREPRESENT DETAIL\n name: Maliki Abdulla Ally\nlevel: Representer\ncompus: Vuga\ncouse: GIS\naccyear: 2018/19","\n\n\t\t\tREPRESENT DETAIL\nname: Marya Muhidin Hamad\nlevel: Representer\ncompus: Mbweni\ncouse: Nurse\naccyear: 2016/17","\n\n\t\t\tREPRESENT DETAIL\nname: Junaina Mussa Kibwan\nlevel: Representer\ncompus: Chwaka\ncouse: BFA\naccyear: 2020/21"};
        int choice=mabii.nextInt();
        switch(choice){
            case 1: System.out.println(detel[1-1]+deteil[1-1]);
            System.out.println("are you ready to vote?\tyes or no");
            Scanner x = new Scanner(System.in);
            String ansa =x.next();
            if(ansa.equalsIgnoreCase(yes)){
                 System.out.println("\t\tcongratulation");
            }
            break;
            case 2: System.out.println(detel[2-1]+deteil[2-1]);
            System.out.println("are you ready to vote?\tyes or no");
            Scanner b = new Scanner(System.in);
            String ans2 =b.next();
            if(ans2.equalsIgnoreCase(yes)){
                 System.out.println("\t\tcongratulation");
            }
            break;
            case 3: System.out.println(detel[3-1]+deteil[3-1]);
            System.out.println("are you ready to vote?\tyes or no");
            Scanner n = new Scanner(System.in);
            String ans3 =n.next();
            if(ans3.equalsIgnoreCase(yes)){
                 System.out.println("\t\tcongratulation");
            }
            break;
            case 4: System.out.println(detel[4-1]+deteil[4-1]);
            System.out.println("are you ready to vote?\tyes or no");
            Scanner m = new Scanner(System.in);
            String ans4 =m.next();
            if(ans4.equalsIgnoreCase(yes)){
                 System.out.println("\t\tcongratulation");
            }
            break;
        }
        System.out.println("menu:1");
        Scanner lii=new Scanner(System.in);
        menu=lii.nextInt();
        }
        while(menu==1); 
    }
}