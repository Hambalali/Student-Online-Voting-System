import java.util.Scanner;

public class proje2 implements view{
    private String name;
    private String regNo;

    public proje2() {

    }

    public proje2(String nam, String rgNo) {
        name = nam;
        regNo = rgNo;
    }
    public void setname() {
        Scanner ham = new Scanner(System.in);
        System.out.println("Enter your name");
        String name = ham.nextLine();
        this.name = name;
    }

    public void setname(String s) {
        name = s;
    }
    public String getname() { 
        return name;
    }

    public void setregNo(String s) {
        regNo = s;
    }

    public void setregNo() {
        Scanner ali = new Scanner(System.in);
        System.out.println("Enter your regNumber");
        String regNo = ali.nextLine();
        this.regNo = regNo;
    }

    public String getregNo() {
        return regNo;
    }

    public void copy() {
        this.setname(getname());
        this.setregNo(getregNo());
    }
    public String toStringx(){
        return "you are elligible for voting as\n" + getname() + "\nwith registration number\n" + getregNo();
    }
}
